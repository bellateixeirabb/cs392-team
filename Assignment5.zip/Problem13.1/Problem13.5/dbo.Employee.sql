﻿CREATE TABLE [dbo].[Employee] (
    [Employee Id]     INT           IDENTITY (1, 1) NOT NULL,
    [name]            NVARCHAR (50) NOT NULL,
    [position]        NVARCHAR (50) NOT NULL,
    [hourly pay rate] INT NOT NULL,
    PRIMARY KEY CLUSTERED ([Employee Id] ASC)
);

