﻿namespace Problem13._5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TableWithInfo = new System.Windows.Forms.DataGridView();
            this.personnelDataSet = new Problem13._5.PersonnelDataSet();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.employeeTableAdapter1 = new Problem13._5.PersonnelDataSetTableAdapters.EmployeeTableAdapter();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaxButtonRemake = new System.Windows.Forms.Button();
            this.MinButtonRemake = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.TableWithInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.personnelDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // TableWithInfo
            // 
            this.TableWithInfo.AutoGenerateColumns = false;
            this.TableWithInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TableWithInfo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.TableWithInfo.DataSource = this.bindingSource1;
            this.TableWithInfo.Location = new System.Drawing.Point(99, 109);
            this.TableWithInfo.Name = "TableWithInfo";
            this.TableWithInfo.RowHeadersWidth = 51;
            this.TableWithInfo.RowTemplate.Height = 24;
            this.TableWithInfo.Size = new System.Drawing.Size(554, 150);
            this.TableWithInfo.TabIndex = 0;
            // 
            // personnelDataSet
            // 
            this.personnelDataSet.DataSetName = "PersonnelDataSet";
            this.personnelDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingSource1
            // 
            this.bindingSource1.DataMember = "Employee";
            this.bindingSource1.DataSource = this.personnelDataSet;
            // 
            // employeeTableAdapter1
            // 
            this.employeeTableAdapter1.ClearBeforeFill = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Employee Id";
            this.dataGridViewTextBoxColumn1.HeaderText = "Employee Id";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "name";
            this.dataGridViewTextBoxColumn2.HeaderText = "name";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "position";
            this.dataGridViewTextBoxColumn3.HeaderText = "position";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "hourly pay rate";
            this.dataGridViewTextBoxColumn4.HeaderText = "hourly pay rate";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // MaxButtonRemake
            // 
            this.MaxButtonRemake.Location = new System.Drawing.Point(99, 444);
            this.MaxButtonRemake.Name = "MaxButtonRemake";
            this.MaxButtonRemake.Size = new System.Drawing.Size(75, 23);
            this.MaxButtonRemake.TabIndex = 1;
            this.MaxButtonRemake.Text = "Max";
            this.MaxButtonRemake.UseVisualStyleBackColor = true;
            this.MaxButtonRemake.Click += new System.EventHandler(this.MaxButtonRemake_Click);
            // 
            // MinButtonRemake
            // 
            this.MinButtonRemake.Location = new System.Drawing.Point(578, 444);
            this.MinButtonRemake.Name = "MinButtonRemake";
            this.MinButtonRemake.Size = new System.Drawing.Size(75, 23);
            this.MinButtonRemake.TabIndex = 2;
            this.MinButtonRemake.Text = "Min";
            this.MinButtonRemake.UseVisualStyleBackColor = true;
            this.MinButtonRemake.Click += new System.EventHandler(this.MinButtonRemake_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(755, 659);
            this.Controls.Add(this.MinButtonRemake);
            this.Controls.Add(this.MaxButtonRemake);
            this.Controls.Add(this.TableWithInfo);
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.TableWithInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.personnelDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private PersonnelDataSet1 personnelDataSet1;
        private System.Windows.Forms.BindingSource employeeBindingSource;
        private PersonnelDataSet1TableAdapters.EmployeeTableAdapter employeeTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hourlyPayRateDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button MinButton;
        private System.Windows.Forms.Button MaxButton;
        private System.Windows.Forms.DataGridView TableWithInfo;
        private PersonnelDataSet personnelDataSet;
        private System.Windows.Forms.BindingSource bindingSource1;
        private PersonnelDataSetTableAdapters.EmployeeTableAdapter employeeTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.Button MaxButtonRemake;
        private System.Windows.Forms.Button MinButtonRemake;
    }
}

